package com.railse.hiring.workforcemgmt.model;

import lombok.Data;
import java.time.Instant;

@Data
public class Comment {
    private Long taskId;
    private String user;
    private String message;
    private Instant timestamp = Instant.now();
}
