package com.railse.hiring.workforcemgmt.repository;

import com.railse.hiring.workforcemgmt.model.Comment;
import java.util.List;

public interface CommentRepository {
    void addComment(Comment comment);
    List<Comment> getCommentsForTask(Long taskId);
}
