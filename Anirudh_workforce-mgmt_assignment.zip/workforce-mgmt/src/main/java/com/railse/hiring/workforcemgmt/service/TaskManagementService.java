package com.railse.hiring.workforcemgmt.service;

import com.railse.hiring.workforcemgmt.dto.*;

import java.util.List;

public interface TaskManagementService {

    List<TaskManagementDto> createTasks(TaskCreateRequest request);

    List<TaskManagementDto> updateTasks(UpdateTaskRequest request);

    String assignByReference(AssignByReferenceRequest request);

    List<TaskManagementDto> fetchTasksByDate(TaskFetchByDateRequest request);

    // ⛔ REPLACED: TaskManagementDto findTaskById(Long id);
    EnrichedTaskDto findTaskById(Long id);  // ✅ now includes comments + activity

    // ✅ Feature 2.1: Update priority of a task
    TaskManagementDto updateTaskPriority(Long taskId, String newPriority);

    // ✅ Feature 2.2: Fetch all tasks by priority
    List<TaskManagementDto> getTasksByPriority(String priority);

    // ✅ Feature 3.1: Add a user comment to a task
    void addComment(Long taskId, String user, String message);
}
