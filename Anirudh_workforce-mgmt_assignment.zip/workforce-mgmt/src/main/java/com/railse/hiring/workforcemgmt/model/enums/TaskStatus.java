package com.railse.hiring.workforcemgmt.model.enums; 
 
public enum TaskStatus { 
   ASSIGNED, 
   STARTED, 
   COMPLETED, 
   CANCELLED 
} 