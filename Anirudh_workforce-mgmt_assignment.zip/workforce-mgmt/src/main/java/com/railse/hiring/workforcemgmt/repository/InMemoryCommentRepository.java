package com.railse.hiring.workforcemgmt.repository;

import com.railse.hiring.workforcemgmt.model.Comment;
import org.springframework.stereotype.Repository;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Repository
public class InMemoryCommentRepository implements CommentRepository {
    private final Map<Long, List<Comment>> commentStore = new ConcurrentHashMap<>();

    @Override
    public void addComment(Comment comment) {
        commentStore.computeIfAbsent(comment.getTaskId(), k -> new ArrayList<>()).add(comment);
    }

    @Override
    public List<Comment> getCommentsForTask(Long taskId) {
        return commentStore.getOrDefault(taskId, new ArrayList<>());
    }
}
