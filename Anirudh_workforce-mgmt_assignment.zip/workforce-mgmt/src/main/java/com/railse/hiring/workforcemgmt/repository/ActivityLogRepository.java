package com.railse.hiring.workforcemgmt.repository;

import com.railse.hiring.workforcemgmt.model.ActivityLog;
import java.util.List;

public interface ActivityLogRepository {
    void log(ActivityLog activity);
    List<ActivityLog> getLogsForTask(Long taskId);
}
