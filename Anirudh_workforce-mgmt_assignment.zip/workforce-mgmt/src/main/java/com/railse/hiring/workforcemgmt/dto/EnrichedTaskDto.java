package com.railse.hiring.workforcemgmt.dto;

import com.railse.hiring.workforcemgmt.model.ActivityLog;
import com.railse.hiring.workforcemgmt.model.Comment;
import lombok.Data;

import java.util.List;

@Data
public class EnrichedTaskDto {
    private TaskManagementDto task;
    private List<Comment> comments;
    private List<ActivityLog> activityLogs;
}
