package com.railse.hiring.workforcemgmt.repository;

import com.railse.hiring.workforcemgmt.model.ActivityLog;
import org.springframework.stereotype.Repository;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Repository
public class InMemoryActivityLogRepository implements ActivityLogRepository {
    private final Map<Long, List<ActivityLog>> logStore = new ConcurrentHashMap<>();

    @Override
    public void log(ActivityLog log) {
        logStore.computeIfAbsent(log.getTaskId(), k -> new ArrayList<>()).add(log);
    }

    @Override
    public List<ActivityLog> getLogsForTask(Long taskId) {
        return logStore.getOrDefault(taskId, new ArrayList<>());
    }
}
