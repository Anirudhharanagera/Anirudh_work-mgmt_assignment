package com.railse.hiring.workforcemgmt.model;

import lombok.Data;
import java.time.Instant;

@Data
public class ActivityLog {
    private Long taskId;
    private String message;
    private Instant timestamp = Instant.now();
}
