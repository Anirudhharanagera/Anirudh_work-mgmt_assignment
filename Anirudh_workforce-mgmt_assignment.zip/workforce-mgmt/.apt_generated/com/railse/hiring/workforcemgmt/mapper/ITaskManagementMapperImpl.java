package com.railse.hiring.workforcemgmt.mapper;

import com.railse.hiring.workforcemgmt.dto.TaskManagementDto;
import com.railse.hiring.workforcemgmt.model.TaskManagement;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.processing.Generated;
import org.springframework.stereotype.Component;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2025-08-02T15:08:37+0530",
    comments = "version: 1.5.5.Final, compiler: Eclipse JDT (IDE) 3.41.0.v20250213-1140, environment: Java 21.0.6 (Eclipse Adoptium)"
)
@Component
public class ITaskManagementMapperImpl implements ITaskManagementMapper {

    @Override
    public TaskManagementDto modelToDto(TaskManagement model) {
        if ( model == null ) {
            return null;
        }

        TaskManagementDto taskManagementDto = new TaskManagementDto();

        taskManagementDto.setAssigneeId( model.getAssigneeId() );
        taskManagementDto.setDescription( model.getDescription() );
        taskManagementDto.setId( model.getId() );
        taskManagementDto.setPriority( model.getPriority() );
        taskManagementDto.setReferenceId( model.getReferenceId() );
        taskManagementDto.setReferenceType( model.getReferenceType() );
        taskManagementDto.setStatus( model.getStatus() );
        taskManagementDto.setTask( model.getTask() );
        taskManagementDto.setTaskDeadlineTime( model.getTaskDeadlineTime() );

        return taskManagementDto;
    }

    @Override
    public TaskManagement dtoToModel(TaskManagementDto dto) {
        if ( dto == null ) {
            return null;
        }

        TaskManagement taskManagement = new TaskManagement();

        taskManagement.setAssigneeId( dto.getAssigneeId() );
        taskManagement.setDescription( dto.getDescription() );
        taskManagement.setId( dto.getId() );
        taskManagement.setPriority( dto.getPriority() );
        taskManagement.setReferenceId( dto.getReferenceId() );
        taskManagement.setReferenceType( dto.getReferenceType() );
        taskManagement.setStatus( dto.getStatus() );
        taskManagement.setTask( dto.getTask() );
        taskManagement.setTaskDeadlineTime( dto.getTaskDeadlineTime() );

        return taskManagement;
    }

    @Override
    public List<TaskManagementDto> modelListToDtoList(List<TaskManagement> models) {
        if ( models == null ) {
            return null;
        }

        List<TaskManagementDto> list = new ArrayList<TaskManagementDto>( models.size() );
        for ( TaskManagement taskManagement : models ) {
            list.add( modelToDto( taskManagement ) );
        }

        return list;
    }

    @Override
    public List<TaskManagement> dtoListToModelList(List<TaskManagementDto> dtos) {
        if ( dtos == null ) {
            return null;
        }

        List<TaskManagement> list = new ArrayList<TaskManagement>( dtos.size() );
        for ( TaskManagementDto taskManagementDto : dtos ) {
            list.add( dtoToModel( taskManagementDto ) );
        }

        return list;
    }
}
